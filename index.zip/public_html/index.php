<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="description" content="輝夜kaguya生存伺服器 | Minecraft PE">
    <meta name="keywords" content="輝夜伺服器, 輝夜, kaguya, Minecraft PE伺服器, Minecraft 手機版伺服器">
    <meta name="author" content="冰川">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>輝夜生存伺服器</title>
    <link rel="icon" href="../assets/hub/icon.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/index.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <script>
        window.location.href='html/index.html'
    </script>
</body>
</html>