var app = new Vue({
    el: '#app',
    data: {
      info:[
        {'nickName':'冰川','img':'../assets/photos/mcc.png',"job":"網頁、插件編寫兼指令師","info":'一段簡單的介紹...'},
        {'nickName':'夢語','img':'../assets/photos/dream.png',"job":"服主","info":'一段簡單的介紹...',"https://youtube.com/channel/UClQZJFaXxnOH5uu2m66SDQA":""},
      ]
    }
})