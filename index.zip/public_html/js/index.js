//排版調整
$(".mainDiv").css("height",screen.height*0.9)
$(".meddle").css("margin-left",(50-($(".meddle").width()/screen.width)*69)+"%")